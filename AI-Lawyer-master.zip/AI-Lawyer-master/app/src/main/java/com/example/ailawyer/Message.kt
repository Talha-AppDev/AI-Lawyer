package com.example.ailawyer

data class Message(val text: String, val time: String, val isUser: Boolean)